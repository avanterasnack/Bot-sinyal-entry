module.exports = {
  BOT_TOKEN: '7290478038:AAEHC2yxqdWj-O-9DZUD7Pp5Vhvn3F7H9L8',
  OWNER_ID: 1478960880, // ganti dengan ID Telegram kamu
  CHANNEL_LINK: 'https://t.me/SinyalEntryChannel', // optional
  API_KEY_MARKET: 'apikeymu', // bisa pakai CoinMarketCap, AlphaVantage, dll
};